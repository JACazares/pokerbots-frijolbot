import eval7
import numpy as np

ranks = eval7.ranks
suits = eval7.suits
rank_index = np.arange(13)